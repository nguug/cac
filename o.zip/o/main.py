import os
import time
import json
import threading

# Bat che đo im lang cho core bot va CHO PHEP auto-restart khi API goc tat
os.environ.setdefault('FFBOT_QUIET', '1')
os.environ.setdefault('FFBOT_NO_RESTART', '0')

# Reuse existing client and packet builders
import boton as bot
from byte import join_teamcode


def pick_account():
    try:
        with open('accs.txt', 'r') as f:
            data = json.load(f)
        items = list(data.items())
        if not items:
            raise ValueError('accs.txt rong')
        return items[0][0], items[0][1]
    except Exception:
        # Fallback to the hardcoded in boton.py if accs.txt not available
        return 


def start_client_async(id_value: str, password: str, holder: dict):
    # FF_CLIENT.__init__ cua bot se ket noi blocking; ta monkeypatch đe khong block
    try:
        FF = bot.FF_CLIENT
        if not getattr(FF, '_patched_nonblocking_init', False):
            orig_init = FF.__init__
            def nb_init(self, id, password):
                # Khong goi get_tok o __init__ đe tranh block
                threading.Thread.__init__(self)
                self.id = id
                self.password = password
                self.key = None
                self.iv = None
            FF.__init__ = nb_init
            FF._patched_nonblocking_init = True
        client = FF(id=id_value, password=password)
        holder['client'] = client
        # Chay get_tok trong nen đe thuc hien bat tay va thiet lap key/iv
        threading.Thread(target=client.get_tok, daemon=True).start()
    except Exception as e:
        print(f"[client] Loi khoi tao: {e}")


def socket_alive() -> bool:
    try:
        if 'socket_client' in bot.__dict__:
            bot.socket_client.getpeername()
            return True
    except Exception:
        return False
    return False


def ensure_connected(id_value: str, password: str, holder: dict, wait_sec: int = 30):
    if holder.get('client') is None or not socket_alive():
        start_client_async(id_value, password, holder)
        wait_ready(holder, timeout_sec=wait_sec)
        ensure_keys_synced(holder, timeout_sec=wait_sec)
    return holder.get('client')


# Quan ly tac vu nen (vi du: /lag)
background_threads = []


def wait_ready(holder: dict, timeout_sec: int = 30) -> bool:
    start = time.time()
    while time.time() - start < timeout_sec:
        # socket cua online server
        if 'socket_client' in bot.__dict__:
            try:
                bot.socket_client.getpeername()
                return True
            except Exception:
                pass
        time.sleep(0.2)
    return False


def ensure_keys_synced(holder: dict, timeout_sec: int = 30) -> bool:
    start = time.time()
    while time.time() - start < timeout_sec:
        client = holder.get('client')
        if client is not None and getattr(client, 'key', None) and getattr(client, 'iv', None):
            try:
                # Luu key/iv vao scope module `boton` đe cac method noi bo su dung
                if isinstance(client.key, str):
                    bot.key = bytes.fromhex(client.key)
                else:
                    bot.key = client.key
                if isinstance(client.iv, str):
                    bot.iv = bytes.fromhex(client.iv)
                else:
                    bot.iv = client.iv
                return True
            except Exception:
                pass
        time.sleep(0.2)
    return False


def print_menu():
    print("--- Menu ---")
    print("1. /x [id] - Thay the ID")
    print("2. /room [id] - Vao phong")
    print("3. /admin - Quan tri Admin")
    print("4. /inv [id] [3|4|5|6] - Moi ID (mac đinh 5)")
    print("5. /3 -> /4 -> /5 -> /6 - Chuyen che đo đoi")
    print("6. /lag [team_code] [repeat] - Lam lag team code (mac đinh 1, toi đa 3)")
    print("7. /attack [team_code] - Tan cong team code")
    print("8. /start [team_code] [count] - Bat đau team code (mac đinh 20, toi đa 50)")
    print("9. /solo - Roi đoi va ve Solo")
    print("10. /exit - Thoat")
    print("-> Nhap lenh:")


def main():
    id_value, password = pick_account()
    client_holder = {}

    th = threading.Thread(target=start_client_async, args=(id_value, password, client_holder), daemon=True)
    th.start()

    # Cho san sang nhung khong in log
    wait_ready(client_holder, timeout_sec=60)
    ensure_keys_synced(client_holder, timeout_sec=60)

    client = client_holder.get('client')
    print_menu()

    while True:
        try:
            line = input("-> Nhap lenh: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nĐa thoat.")
            break
        if not line:
            continue
        # Đam bao luon ket noi hoat đong truoc khi xu ly lenh
        client = ensure_connected(id_value, password, client_holder, wait_sec=20) or client
        if client is None:
            print("[!] Chua san sang, thu lai sau...")
            continue
        parts = line.split()
        cmd, args = parts[0].lower(), parts[1:]

        if cmd in ("/exit", "exit", "quit"):
            print("Đang thoat...")
            break

        if cmd in ("/lag", "lag"):
            if len(args) < 1:
                print("Dung: /lag [team_code] [repeat=1]")
                continue
            team_code = args[0]
            repeat_count = 1
            if len(args) > 1 and args[1].isdigit():
                repeat_count = min(int(args[1]), 3)
            def _lag_task():
                print(f"[lag] Bat đau, lap {repeat_count} lan...")
                try:
                    c = ensure_connected(id_value, password, client_holder, wait_sec=20) or client
                    if c is None or not hasattr(c, 'leave_s'):
                        print("[lag] Client chua san sang, thu lai sau...")
                        return
                    for _ in range(repeat_count):
                        for __ in range(300):
                            join_teamcode(bot.socket_client, team_code, bot.key, bot.iv)
                            time.sleep(0.003)
                            bot.socket_client.send(c.leave_s())
                            time.sleep(0.003)
                    print("[lag] Hoan tat.")
                except Exception as e:
                    print(f"[lag] Loi: {e}")
            t = threading.Thread(target=_lag_task, daemon=True)
            t.start()
            background_threads.append(t)
            continue

        if cmd in ("/attack", "attack"):
            if len(args) < 1:
                print("Dung: /attack [team_code]")
                continue
            team_code = args[0]
            print(f"[attack] Tan cong {team_code} trong 45s...")
            try:
                client = ensure_connected(id_value, password, client_holder, wait_sec=20) or client
                if client is None or not hasattr(client, 'start_autooo'):
                    print("[attack] Client chua san sang, thu lai...")
                    continue
                start_packet = client.start_autooo()
                leave_packet = client.leave_s()
                end_time = time.time() + 45
                while time.time() < end_time:
                    join_teamcode(bot.socket_client, team_code, bot.key, bot.iv)
                    bot.socket_client.send(start_packet)
                    bot.socket_client.send(leave_packet)
                    time.sleep(0.15)
                print("[attack] Hoan tat.")
            except Exception as e:
                print(f"[attack] Loi: {e}")
            continue

        if cmd in ("/start", "start"):
            if len(args) < 1:
                print("Dung: /start [team_code] [count=20]")
                continue
            team_code = args[0]
            spam_count = 20
            if len(args) > 1 and args[1].isdigit():
                spam_count = min(int(args[1]), 50)
            try:
                client = ensure_connected(id_value, password, client_holder, wait_sec=20) or client
                if client is None or not hasattr(client, 'start_autooo'):
                    print("[start] Client chua san sang, thu lai...")
                    continue
                join_teamcode(bot.socket_client, team_code, bot.key, bot.iv)
                time.sleep(2)
                start_packet = client.start_autooo()
                for _ in range(spam_count):
                    bot.socket_client.send(start_packet)
                    time.sleep(0.2)
                bot.socket_client.send(client.leave_s())
                print("[start] Xong.")
            except Exception as e:
                print(f"[start] Loi: {e}")
            continue

        if cmd in ("/inv", "inv"):
            if len(args) < 1:
                print("Dung: /inv [id] [3|4|5|6] (mac đinh 5)")
                continue
            player_id = args[0]
            squad_type = 5
            if len(args) > 1 and args[1].isdigit():
                squad_type = int(args[1])
            if squad_type < 3 or squad_type > 6:
                print("Loai đoi hop le: 3, 4, 5, 6")
                continue
            try:
                bot.socket_client.send(client.skwad_maker())
                time.sleep(1)
                bot.socket_client.send(client.changes(squad_type - 1))
                bot.socket_client.send(client.invite_skwad(player_id))
                print(f"[inv] Đa gui loi moi toi {player_id} voi đoi {squad_type} nguoi.")
            except Exception as e:
                print(f"[inv] Loi: {e}")
            continue

        if cmd in ("/room", "room"):
            if len(args) < 1:
                print("Dung: /room [id]")
                continue
            player_id = args[0]
            try:
                client = ensure_connected(id_value, password, client_holder, wait_sec=20) or client
                if client is None or not hasattr(client, 'createpacketinfo'):
                    print("[room] Client chua san sang, thu lai...")
                    continue
                bot.socket_client.send(client.createpacketinfo(player_id))
                t0 = time.time()
                found = False
                while time.time() - t0 < 6:
                    if getattr(bot, 'tempdata', None) and "IN ROOM" in str(bot.tempdata):
                        found = True
                        break
                    time.sleep(0.2)
                if not found:
                    print("[room] Nguoi choi khong o trong phong hoac timeout.")
                else:
                    rid = bot.get_idroom_by_idplayer(bot.data22)
                    pkt = client.spam_room(rid, player_id)
                    for _ in range(30):
                        bot.socket_client.send(pkt)
                    print(f"[room] Đa spam phong {rid} cua {player_id}.")
            except Exception as e:
                print(f"[room] Loi: {e}")
            continue

        if cmd in ("/3", "3", "/4", "4", "/5", "5", "/6", "6"):
            mapping = {"/3": 2, "3": 2, "/4": 3, "4": 3, "/5": 4, "5": 4, "/6": 5, "6": 5}
            num = mapping[cmd]
            try:
                bot.socket_client.send(client.skwad_maker())
                time.sleep(0.5)
                bot.socket_client.send(client.changes(num))
                if len(args) >= 1:
                    bot.socket_client.send(client.invite_skwad(args[0]))
                print(f"[mode] Đa chuyen che đo đoi (ma {num}).")
            except Exception as e:
                print(f"[mode] Loi: {e}")
            continue

        if cmd in ("/x", "x"):
            if len(args) < 1:
                print("Dung: /x [id]")
                continue
            player_id = args[0]
            try:
                client = ensure_connected(id_value, password, client_holder, wait_sec=20) or client
                if client is None or not hasattr(client, 'request_skwad'):
                    print("[x] Client chua san sang, thu lai...")
                    continue
                def _send_inv():
                    pkt = client.request_skwad(player_id)
                    bot.socket_client.send(pkt)
                ths = []
                for _ in range(100):
                    t = threading.Thread(target=_send_inv)
                    t.start()
                    ths.append(t)
                for t in ths:
                    t.join()
                print(f"[x] Đa spam loi moi toi {player_id}.")
            except Exception as e:
                print(f"[x] Loi: {e}")
            continue

        if cmd in ("/solo", "solo"):
            try:
                bot.socket_client.send(client.leave_s())
                time.sleep(1)
                bot.socket_client.send(client.changes(1))
                print("[solo] Đa roi đoi va chuyen ve Solo.")
            except Exception as e:
                print(f"[solo] Loi: {e}")
            continue

        if cmd in ("/admin", "admin"):
            print("Lien he Admin: Telegram @lon1237 | IG @thanhtung")
            continue

        print("Lenh khong hop le. Go /exit đe thoat hoac thu lai.")


if __name__ == '__main__':
    main()


